class Cell
{
    constructor ( posx, posy)
    {
        this.isWall = false;
        this.posx = posx;
        this.posy = posy;
        this.CostSoFar = 0;
        this.pcost = 0;
        this.total = 0;
    }

    isWall()
    {
        return this.isWall;
    }

    setIsWall(wall)
    {
        this.isWall = wall;
    }
}
var arrayOfCells = [[]];
for (let i = 0; i <= 30; i++) {
    arrayOfCells[i] = [];
    for (let j = 0; j <= 20; j++) {
        arrayOfCells[i][j] = new Cell(i, j);
    } 
}