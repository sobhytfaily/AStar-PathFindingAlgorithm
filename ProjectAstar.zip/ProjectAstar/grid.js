
var canvas = document.getElementById("grid");

//Global variables
var cols = 67;
var rows = 40;
var w;
var h;
var path = [];
var Canvasheight = 600;
var Canvaswidth = 1000;

var openList = [];
var closedList = [];
var grid = [[]];
var start = undefined;
var end;
var count = 0;
var startwait = false;


var grid = new Array(cols);




function GridCell(i, j) {
    this.i = i;
    this.j = j;
    this.f = 0;
    this.g = 0;
    this.h = 0;
    this.wall = false;
    this.neighbors = [];
    this.parent = undefined;

    if (Math.random(1) < 0.3) {
        this.wall = true;
    }
    this.show = function (color) {
        fill(color);
        if (this.wall) {
            fill(0);
        }
        noStroke();
        rect(this.i * w, this.j * h, w - 1, h - 1);

    }
    this.addNeighbors = function () {
        if (this.i < cols - 1) {
            this.neighbors.push(grid[this.i + 1][this.j]);
        }
        if (i > 0) {
            this.neighbors.push(grid[this.i - 1][this.j]);
        }
        if (this.j < rows - 1) {
            this.neighbors.push(grid[this.i][this.j + 1]);
        }
        if (this.j > 0) {
            this.neighbors.push(grid[this.i][this.j - 1]);
        }
        if (this.i < cols - 1 && this.j < rows - 1) {
            this.neighbors.push(grid[this.i + 1][this.j + 1]);
        }
        if (this.i > 0 && this.j > 0) {
            this.neighbors.push(grid[this.i - 1][this.j - 1]);
        }
        if (this.i < cols - 1 && this.j > 0) {
            this.neighbors.push(grid[this.i + 1][this.j - 1]);
        }
        if (this.i > 0 && this.j < rows - 1) {
            this.neighbors.push(grid[this.i - 1][this.j + 1]);
        }

    }
}



function setup() {
    createCanvas(1000, 600);
    w = Canvaswidth / cols;
    h = Canvasheight / rows;
    console.log('A*');
    for (let i = 0; i < cols; i++) {
        grid[i] = new Array(rows);
        for (let j = 0; j < rows; j++) {
            grid[i][j] = new GridCell(i, j);
        }
    }
    for (let i = 0; i < cols; i++) {
        for (let j = 0; j < rows; j++) {
            grid[i][j].addNeighbors();
        }
    }
    console.log(grid);
    canvas.addEventListener("click", canvasClick, false);
    function canvasClick(e) {
        if (e.pageX != undefined && e.pageY != undefined) {
            x = e.pageX;
            y = e.pageY;
        } else {
            x = e.clientX + document.body.scrollLeft + document.documentElement.scrollLeft;
            y = e.clientY + document.body.scrollTop + document.documentElement.scrollTop;
        }
        x -= canvas.offsetLeft;
        y -= canvas.offsetTop;

        x = Math.floor(x / 15);
        y = Math.floor(y / 15);
        if (!grid[x][y].wall) {
            count++;
            if (count == 1) {
                pointStartx = x;
                pointStarty = y;
                start = grid[pointStartx][pointStarty];
                grid[x][y].show('red');
                openList.push(start);
            }
            if (count == 2) {
                pointEndx = x;
                pointEndy = y;
                end = grid[pointEndx][pointEndy];
                startwait = true;
            }
        }
    }

    background(0);
    for (let i = 0; i < cols; i++) {
        for (let j = 0; j < rows; j++) {
            if (grid[i][j] == start) {
                grid[i][j].show('red');
            } else
                if (grid[i][j] == end) {
                    grid[i][j].show('green');
                } else {
                    grid[i][j].show('white');
                }
        }
    }


}
function draw() {
    if (startwait == true) {


        if (openList.length > 0) {
            var closest = 0;
            for (var i = 0; i < openList.length; i++) {
                if (openList[i].f < openList[closest].f) {
                    closest = i;
                }
            }
            var current = openList[closest];
            console.log(current);
            if (current === end) {
                noLoop();
                console.log('done');
            }

            removeElement(openList, current);
            closedList.push(current);

            var neighbors = current.neighbors;
            for (var i = 0; i < neighbors.length; i++) {
                console.log(neighbors[i]);
                var neighbor = neighbors[i];

                if (!closedList.includes(neighbor) && !neighbor.wall) {
                    var tempG = current.g + 1;
                    var newPath = false;
                    if (openList.includes(neighbor)) {
                        if (tempG < neighbor.g) {
                            neighbor.g = tempG;
                            newPath = true;

                        }
                    } else {
                        neighbor.g = tempG;
                        newPath = true;
                        openList.push(neighbor);
                    }
                    if (newPath) {
                        neighbor.h = hueristic(neighbor, end);
                        neighbor.f = neighbor.g + neighbor.h;
                        neighbor.parent = current;
                    }
                }

            }
        } else {
            console.log('no solultion');
            noLoop();
            return;

        }

        background(0);
        for (let i = 0; i < cols; i++) {
            for (let j = 0; j < rows; j++) {
                if (grid[i][j] == start) {
                    grid[i][j].show('red');
                } else
                    if (grid[i][j] == end) {
                        grid[i][j].show('green');
                    } else {
                        grid[i][j].show('white');
                    }
            }
        }
        for (var i = 0; i < closedList.length; i++) {

            closedList[i].show(color(248, 187, 208));
        }

        for (var i = 0; i < openList.length; i++) {
            openList[i].show('yellow');
        }


        path = [];
        var temp = current;
        path.push(temp);
        while (temp.parent) {

            path.push(temp.parent);
            temp = temp.parent;
        }
        for (var i = 0; i < path.length; i++) {
            path[i].show(color(240, 98, 146));
        }
    }
}
function removeElement(array, element) {
    for (let i = array.length - 1; i >= 0; i--) {
        if (array[i] == element)
            array.splice(i, 1);
    }
}
function hueristic(point, end) {
    return abs(point.i - end.i) + abs(point.j - end.j);
}
